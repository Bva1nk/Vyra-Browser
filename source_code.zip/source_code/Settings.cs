using System;
using System.IO;
using System.Text.Json;

namespace Vyra_Browser
{
    public class BrowserSettings
    {
        public string Homepage { get; set; } = "https://www.bing.com";
        public string SearchEngine { get; set; } = "Bing";
        public string StartupMode { get; set; } = "Homepage"; // Homepage | NewTab | LastSession
        public string LastUrl { get; set; } = "";
        public bool IsJavaScriptEnabled { get; set; } = true;
        public double ZoomFactor { get; set; } = 1.0; // 1.0 = 100%
        public string DownloadFolder { get; set; } = "";
        public System.Collections.Generic.List<string> OpenTabs { get; set; } = new System.Collections.Generic.List<string>();

        private static string SettingsFolder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Vyra Browser");
        private static string SettingsFile => Path.Combine(SettingsFolder, "settings.json");

        public static BrowserSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder)) Directory.CreateDirectory(SettingsFolder);
                if (!File.Exists(SettingsFile))
                {
                    var s = new BrowserSettings();
                    s.Save();
                    return s;
                }

                var json = File.ReadAllText(SettingsFile);
                var opts = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var settings = JsonSerializer.Deserialize<BrowserSettings>(json, opts);
                return settings ?? new BrowserSettings();
            }
            catch
            {
                return new BrowserSettings();
            }
        }

        public void Save()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder)) Directory.CreateDirectory(SettingsFolder);
                var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
                // ignore disk failures
            }
        }
    }
}
