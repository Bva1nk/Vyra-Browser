using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using Microsoft.Web.WebView2.Core;

namespace Vyra_Browser
{
    public class SettingsWebForm : Form
    {
        private WebView2 webView;
        private BrowserSettings settings;

        public SettingsWebForm(BrowserSettings current)
        {
            settings = current ?? BrowserSettings.Load();
            this.Text = "Settings";
            this.StartPosition = FormStartPosition.CenterParent;
            this.ClientSize = new System.Drawing.Size(700, 400);

            webView = new WebView2();
            webView.Dock = DockStyle.Fill;
            this.Controls.Add(webView);

            _ = InitializeAsync();
        }

        private async Task InitializeAsync()
        {
            try
            {
                await webView.EnsureCoreWebView2Async();
                webView.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;

                // load local HTML from the files folder
                var exe = AppContext.BaseDirectory;
                var htmlPath = Path.Combine(exe, "files", "settings.html");
                if (File.Exists(htmlPath))
                {
                    var html = File.ReadAllText(htmlPath);
                    // ensure the webview has a proper base URI so relative resources (if any) resolve
                    webView.NavigateToString(html);
                }
                else
                {
                    webView.NavigateToString("<html><body><h3>Settings page not found</h3><p>Expected path: " + System.Web.HttpUtility.HtmlEncode(htmlPath) + "</p></body></html>");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to initialize settings page: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CoreWebView2_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                var json = e.TryGetWebMessageAsString();
                if (string.IsNullOrWhiteSpace(json)) return;
                using var doc = JsonDocument.Parse(json);
                if (!doc.RootElement.TryGetProperty("type", out var typeEl)) return;
                var type = typeEl.GetString();
                if (type == "getSettings")
                {
                    var payload = JsonSerializer.Serialize(new { type = "settings", payload = settings });
                    webView.CoreWebView2.PostWebMessageAsJson(payload);
                }
                else if (type == "saveSettings")
                {
                    if (doc.RootElement.TryGetProperty("payload", out var p))
                    {
                        try
                        {
                            var newSettings = JsonSerializer.Deserialize<BrowserSettings>(p.GetRawText());
                            if (newSettings != null)
                            {
                                settings.Homepage = newSettings.Homepage ?? settings.Homepage;
                                settings.SearchEngine = newSettings.SearchEngine ?? settings.SearchEngine;
                                settings.StartupMode = newSettings.StartupMode ?? settings.StartupMode;
                                settings.IsJavaScriptEnabled = newSettings.IsJavaScriptEnabled;
                                settings.ZoomFactor = newSettings.ZoomFactor <= 0 ? settings.ZoomFactor : newSettings.ZoomFactor;
                                settings.DownloadFolder = newSettings.DownloadFolder ?? settings.DownloadFolder;
                                settings.Save();
                                // notify page
                                var payload = JsonSerializer.Serialize(new { type = "saved" });
                                webView.CoreWebView2.PostWebMessageAsJson(payload);
                            }
                        }
                        catch { }
                    }
                }
                else if (type == "chooseFolder")
                {
                    try
                    {
                        using var dlg = new FolderBrowserDialog();
                        dlg.Description = "Select download folder";
                        var res = dlg.ShowDialog(this);
                        if (res == DialogResult.OK)
                        {
                            var payload = JsonSerializer.Serialize(new { type = "chosenFolder", payload = dlg.SelectedPath });
                            webView.CoreWebView2.PostWebMessageAsJson(payload);
                        }
                    }
                    catch { }
                }
                else if (type == "clearBrowsingData")
                {
                    try
                    {
                        // delete cookies and clear localStorage
                        webView.CoreWebView2.CookieManager.DeleteAllCookies();
                        webView.CoreWebView2.ExecuteScriptAsync("localStorage.clear(); sessionStorage.clear();");
                        var payload = JsonSerializer.Serialize(new { type = "cleared" });
                        webView.CoreWebView2.PostWebMessageAsJson(payload);
                    }
                    catch { }
                }
            }
            catch { }
        }
    }
}
