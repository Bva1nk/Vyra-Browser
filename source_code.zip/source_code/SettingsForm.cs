using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vyra_Browser
{
    public class SettingsForm : Form
    {
        private TextBox txtHomepage;
        private ComboBox cmbSearch;
        private Panel previewBox;
        private Button btnSave;
        private Button btnCancel;
        private BrowserSettings settings = null!;

        public SettingsForm()
        {
            this.Text = "Settings";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.ClientSize = new Size(420, 180);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.Black;
            this.ForeColor = Color.LightGray;

            var lblHome = new Label { Text = "Homepage:", Location = new Point(12, 12), AutoSize = true, BackColor = Color.Black, ForeColor = Color.LightGray };
            txtHomepage = new TextBox { Location = new Point(12, 30), Width = 380, BackColor = Color.FromArgb(55, 55, 62), ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

            var lblSearch = new Label { Text = "Search engine:", Location = new Point(12, 62), AutoSize = true, BackColor = Color.Black, ForeColor = Color.LightGray };
            cmbSearch = new ComboBox { Location = new Point(12, 80), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Color.FromArgb(55, 55, 62), ForeColor = Color.White };
            cmbSearch.Items.AddRange(new string[] { "Bing", "Google", "DuckDuckGo" });

            btnSave = new Button { Text = "Save", Location = new Point(236, 140), Size = new Size(75, 28), BackColor = Color.FromArgb(50, 50, 58), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            btnCancel = new Button { Text = "Cancel", Location = new Point(317, 140), Size = new Size(75, 28), BackColor = Color.FromArgb(50, 50, 58), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };

            // a simple black box area (preview / visual separator)
            previewBox = new Panel { Location = new Point(12, 110), Size = new Size(380, 24), BackColor = Color.Black, BorderStyle = BorderStyle.FixedSingle };

            btnSave.Click += BtnSave_Click;
            btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;

            this.Controls.Add(lblHome);
            this.Controls.Add(txtHomepage);
            this.Controls.Add(lblSearch);
            this.Controls.Add(cmbSearch);
            this.Controls.Add(previewBox);
            this.Controls.Add(btnSave);
            this.Controls.Add(btnCancel);

            LoadSettings();
        }

        private void LoadSettings()
        {
            settings = BrowserSettings.Load();
            txtHomepage.Text = settings.Homepage ?? "https://www.bing.com";
            if (!string.IsNullOrEmpty(settings.SearchEngine) && cmbSearch.Items.Contains(settings.SearchEngine))
                cmbSearch.SelectedItem = settings.SearchEngine;
            else
                cmbSearch.SelectedIndex = 0;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            settings.Homepage = string.IsNullOrWhiteSpace(txtHomepage.Text) ? "https://www.bing.com" : txtHomepage.Text.Trim();
            settings.SearchEngine = cmbSearch.SelectedItem?.ToString() ?? "Bing";
            settings.Save();
            this.DialogResult = DialogResult.OK;
        }
    }
}
