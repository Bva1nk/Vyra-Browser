using System;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using Microsoft.Web.WebView2.Core;

namespace Vyra_Browser
{
    public partial class Form1 : Form
    {
        private WebView2 webView = null!;
        private BrowserSettings settings = null!;
        private CoreWebView2Environment webView2Environment = null!;
        private System.Collections.Generic.Dictionary<System.Windows.Forms.TabPage, System.Drawing.Image?> tabFavicons = new System.Collections.Generic.Dictionary<System.Windows.Forms.TabPage, System.Drawing.Image?>();
        private int dragTabIndex = -1;
        private ContextMenuStrip tabContextMenu = null!;

        public Form1()
        {
            InitializeComponent();

            // load settings
            settings = BrowserSettings.Load();

            // UI behaviors
            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;

            // prepare tab context menu
            tabContextMenu = new ContextMenuStrip();
            tabContextMenu.Items.Add("Reload", null, (s,e)=> { var w=GetActiveWebView(); if(w?.CoreWebView2!=null) w.Reload(); });
            tabContextMenu.Items.Add("Close", null, (s,e)=> btnCloseTab_Click(this, EventArgs.Empty));
            tabContextMenu.Items.Add("Close other tabs", null, (s,e)=> CloseOtherTabs());
            tabContextMenu.Items.Add("Duplicate", null, async (s,e)=> { var a=GetActiveWebView(); if(a!=null) await CreateNewTabAsync(a.Source?.ToString() ?? "about:blank"); });

            // enable custom drawing and drag-drop for tabs
            tabControl.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabControl.DrawItem += TabControl_DrawItem;
            tabControl.Paint += TabControl_Paint;
            tabControl.MouseDown += TabControl_MouseDown;
            tabControl.MouseMove += TabControl_MouseMove;
            tabControl.DragOver += TabControl_DragOver;
            tabControl.DragDrop += TabControl_DragDrop;

            // initialize WebView2 environment and create initial tab(s)
            _ = InitializeWebViewAsync();
        }

        private void TabControl_Paint(object? sender, PaintEventArgs e)
        {
            try
            {
                // Fill the entire control with black so no light strip or border remains
                var rectAll = new System.Drawing.Rectangle(0, 0, tabControl.Width, tabControl.Height);
                using var brushAll = new System.Drawing.SolidBrush(System.Drawing.Color.Black);
                e.Graphics.FillRectangle(brushAll, rectAll);
                // Also ensure the header area (above the display rectangle) is black
                var hdrHeight = Math.Max(0, tabControl.DisplayRectangle.Top);
                var rect = new System.Drawing.Rectangle(0, 0, tabControl.Width, hdrHeight);
                using var brush = new System.Drawing.SolidBrush(System.Drawing.Color.Black);
                e.Graphics.FillRectangle(brush, rect);
            }
            catch { }
        }

        private async System.Threading.Tasks.Task InitializeWebViewAsync()
        {
            try
            {
                // Create a WebView2 environment explicitly and use it to initialize the control.
                // This can give clearer errors if the runtime is missing or incompatible.
                var userDataFolder = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Vyra Browser", "WebView2");
                webView2Environment = await CoreWebView2Environment.CreateAsync(null, userDataFolder);

                // Decide startup navigation based on settings
                var homepageRaw = string.IsNullOrWhiteSpace(settings?.Homepage) ? "https://www.bing.com" : settings.Homepage;
                var homepageFinal = BuildNavigationUrl(homepageRaw) ?? "https://www.bing.com";

                string initialUrl;
                if (settings != null && settings.StartupMode == "LastSession" && !string.IsNullOrWhiteSpace(settings.LastUrl))
                {
                    initialUrl = settings.LastUrl;
                }
                else if (settings != null && settings.StartupMode == "NewTab")
                {
                    initialUrl = "about:blank";
                }
                else
                {
                    initialUrl = homepageFinal;
                }

                // Create the first tab (and initialize its WebView2 control)
                if (settings != null && settings.StartupMode == "LastSession" && settings.OpenTabs != null && settings.OpenTabs.Count > 0)
                {
                    foreach (var u in settings.OpenTabs)
                    {
                        var final = string.IsNullOrWhiteSpace(u) ? "about:blank" : u;
                        await CreateNewTabAsync(final);
                    }
                }
                else
                {
                    await CreateNewTabAsync(initialUrl);
                }
            }
            catch (Exception ex)
            {
                try
                {
                    // show more detailed error to help debugging
                    var msg = "WebView2 failed: " + ex.Message;
                    addressBar.Text = msg;
                    MessageBox.Show(ex.ToString(), "WebView2 initialization error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch { }
            }
        }

        private void CoreWebView2_NavigationCompleted(object? sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            // Not used directly now - navigation events are handled per WebView2 instance via CreateNewTabAsync
        }

        private void OnWebViewNavigationCompleted(WebView2 source, CoreWebView2NavigationCompletedEventArgs e)
        {
            try
            {
                this.Invoke((Action)(() =>
                {
                    try { addressBar.Text = source.Source?.ToString() ?? addressBar.Text; } catch { }
                    try { btnBack.Enabled = source.CoreWebView2.CanGoBack; } catch { btnBack.Enabled = false; }
                    try { btnForward.Enabled = source.CoreWebView2.CanGoForward; } catch { btnForward.Enabled = false; }
                    try { this.Text = source.CoreWebView2.DocumentTitle + " - Vyra Browser"; } catch { }

                    // Save last URL if the startup mode requires it
                    try
                    {
                        if (settings != null && settings.StartupMode == "LastSession")
                        {
                            settings.LastUrl = source.Source?.ToString() ?? settings.LastUrl;
                            settings.Save();
                        }
                    }
                    catch { }
                }));
            }
            catch { }
        }

        private void Navigate(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return;

            // Build final navigation URL (handle search queries, hostnames, schemes, ports, etc.)
            var final = BuildNavigationUrl(url.Trim());
            if (final == null) return;

            try
            {
                var active = GetActiveWebView();
                if (active?.CoreWebView2 != null)
                    active.CoreWebView2.Navigate(final);
                else if (active != null)
                    active.Source = new Uri(final);
            }
            catch { }
        }

        private WebView2? GetActiveWebView()
        {
            try
            {
                var tp = tabControl.SelectedTab;
                if (tp == null) return null;
                foreach (Control c in tp.Controls)
                {
                    if (c is WebView2 w) return w;
                }
            }
            catch { }
            return null;
        }

        private string? BuildNavigationUrl(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return null;

            // common schemes we allow through as-is
            var lower = input.ToLowerInvariant();
            if (lower.StartsWith("http://") || lower.StartsWith("https://") || lower.StartsWith("about:") ||
                lower.StartsWith("file:") || lower.StartsWith("mailto:") || lower.StartsWith("data:") ||
                lower.StartsWith("javascript:"))
            {
                return input;
            }

            // If it looks like an absolute URI according to the runtime, use it
            if (Uri.TryCreate(input, UriKind.Absolute, out var abs))
                return abs.ToString();

            // If it starts with www., treat as hostname
            if (lower.StartsWith("www."))
                return "https://" + input;

            // If input contains spaces -> treat as search query
            if (input.Contains(" "))
                return BuildSearchUrl(input);

            // If looks like host:port (contains ':' but no scheme) -> prefix http://
            if (input.Contains(":") && !input.Contains("@") && !input.Contains("/"))
            {
                // e.g. localhost:5000
                return "http://" + input;
            }

            // If it contains a dot and no spaces, likely a domain or IP — prefix https
            if (input.Contains('.'))
            {
                return "https://" + input;
            }

            // Fallback: treat as search
            return BuildSearchUrl(input);
        }

        private string BuildSearchUrl(string query)
        {
            // Choose search provider from settings
            var provider = settings?.SearchEngine ?? "Bing";
            var q = Uri.EscapeDataString(query);
            return provider switch
            {
                "Google" => "https://www.google.com/search?q=" + q,
                "DuckDuckGo" => "https://duckduckgo.com/?q=" + q,
                _ => "https://www.bing.com/search?q=" + q,
            };
        }

        private void btnSettings_Click(object? sender, EventArgs e)
        {
            try
            {
                using var dlg = new SettingsWebForm(settings);
                dlg.ShowDialog(this);
                // reload settings after the web dialog closes
                settings = BrowserSettings.Load();
                try
                {
                    if (!string.IsNullOrWhiteSpace(settings.Homepage))
                        Navigate(settings.Homepage);
                }
                catch { }
            }
            catch { }
        }

        private void btnSettingsMain_Click(object sender, EventArgs e)
        {
            // Forward to the same settings handler
            btnSettings_Click(sender, e);
        }

        private async void btnNewTab_Click(object? sender, EventArgs e)
        {
            await CreateNewTabAsync("about:blank");
        }

        private void btnCloseTab_Click(object? sender, EventArgs e)
        {
            try
            {
                var tp = tabControl.SelectedTab;
                if (tp != null)
                {
                    // dispose contained WebView2
                    foreach (Control c in tp.Controls)
                    {
                        if (c is WebView2 w)
                        {
                            try { w.Dispose(); } catch { }
                        }
                    }
                    tabControl.TabPages.Remove(tp);
                    tp.Dispose();
                }

                if (tabControl.TabPages.Count == 0)
                {
                    // create an empty tab
                    _ = CreateNewTabAsync("about:blank");
                }
                SaveOpenTabs();
            }
            catch { }
        }

        private void tabControl_SelectedIndexChanged(object? sender, EventArgs e)
        {
            try
            {
                var active = GetActiveWebView();
                if (active != null && active.CoreWebView2 != null)
                {
                    addressBar.Text = active.Source?.ToString() ?? addressBar.Text;
                    btnBack.Enabled = active.CoreWebView2.CanGoBack;
                    btnForward.Enabled = active.CoreWebView2.CanGoForward;
                }
                else
                {
                    addressBar.Text = string.Empty;
                    btnBack.Enabled = false;
                    btnForward.Enabled = false;
                }
            }
            catch { }
        }

        private void btnBack_Click(object? sender, EventArgs e)
        {
            try { if (webView?.CoreWebView2 != null && webView.CoreWebView2.CanGoBack) webView.CoreWebView2.GoBack(); }
            catch { }
        }

        private void btnForward_Click(object? sender, EventArgs e)
        {
            try { if (webView?.CoreWebView2 != null && webView.CoreWebView2.CanGoForward) webView.CoreWebView2.GoForward(); }
            catch { }
        }

        private void btnRefresh_Click(object? sender, EventArgs e)
        {
            try { if (webView != null) webView.Reload(); }
            catch { }
        }

        private void btnGo_Click(object? sender, EventArgs e)
        {
            Navigate(addressBar.Text);
        }

        private void addressBar_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                Navigate(addressBar.Text);
            }
        }

        private async System.Threading.Tasks.Task CreateNewTabAsync(string url)
        {
            try
            {
                var tp = new TabPage("New Tab");
                tp.BackColor = System.Drawing.Color.Black;
                tp.ForeColor = System.Drawing.Color.LightGray;
                var wv = new WebView2();
                wv.Dock = DockStyle.Fill;
                tp.Controls.Add(wv);
                tabControl.TabPages.Add(tp);
                tabControl.SelectedTab = tp;

                // initialize webview with shared environment
                if (webView2Environment != null)
                {
                    await wv.EnsureCoreWebView2Async(webView2Environment);
                }
                else
                {
                    await wv.EnsureCoreWebView2Async();
                }

                // apply settings
                try { wv.CoreWebView2.Settings.IsScriptEnabled = settings.IsJavaScriptEnabled; } catch { }
                try { wv.ZoomFactor = settings.ZoomFactor > 0 ? settings.ZoomFactor : 1.0; } catch { }

                // attach navigation completed handler using closure so we know which WebView triggered it
                wv.CoreWebView2.NavigationCompleted += (s, e) => OnWebViewNavigationCompleted(wv, e);
                // attempt to download favicon for the origin and store for drawing
                _ = LoadFaviconAsync(tp, wv);
                try
                {
                    var final = BuildNavigationUrl(url) ?? "about:blank";
                    wv.CoreWebView2.Navigate(final);
                }
                catch
                {
                    try { wv.CoreWebView2.Navigate("about:blank"); } catch { }
                }
                // persist tabs list
                SaveOpenTabs();
            }
            catch (Exception ex)
            {
                try { MessageBox.Show("Failed to create tab: " + ex.Message); } catch { }
            }
        }

        private async System.Threading.Tasks.Task LoadFaviconAsync(TabPage tp, WebView2 wv)
        {
            try
            {
                var src = wv.CoreWebView2?.Source ?? wv.Source?.ToString();
                if (string.IsNullOrWhiteSpace(src)) return;
                if (!Uri.TryCreate(src, UriKind.Absolute, out var u)) return;
                var origin = u.GetLeftPart(UriPartial.Authority);
                var icoUrl = origin.TrimEnd('/') + "/favicon.ico";
                using var client = new System.Net.Http.HttpClient();
                var data = await client.GetByteArrayAsync(icoUrl);
                using var ms = new System.IO.MemoryStream(data);
                var img = System.Drawing.Image.FromStream(ms);
                tabFavicons[tp] = img;
                tabControl.Invalidate();
            }
            catch { tabFavicons[tp] = null; }
        }

        private void CloseOtherTabs()
        {
            try
            {
                var sel = tabControl.SelectedTab;
                if (sel == null) return;
                for (int i = tabControl.TabPages.Count - 1; i >= 0; i--)
                {
                    var tp = tabControl.TabPages[i];
                    if (tp != sel)
                    {
                        foreach (Control c in tp.Controls) if (c is WebView2 w) try { w.Dispose(); } catch { }
                        tabFavicons.Remove(tp);
                        tabControl.TabPages.Remove(tp);
                        tp.Dispose();
                    }
                }
                SaveOpenTabs();
            }
            catch { }
        }

        private void TabControl_DrawItem(object? sender, DrawItemEventArgs e)
        {
            try
            {
                var tp = tabControl.TabPages[e.Index];
                var rect = tabControl.GetTabRect(e.Index);

                // base colors
                var tabBg = System.Drawing.Color.Black;
                var selBg = System.Drawing.Color.FromArgb(30, 30, 30);
                var textColor = System.Drawing.Color.LightGray;

                // draw background for the tab
                using (var bgBrush = new System.Drawing.SolidBrush(e.Index == tabControl.SelectedIndex ? selBg : tabBg))
                {
                    e.Graphics.FillRectangle(bgBrush, rect);
                }

                // draw favicon if available
                var textX = rect.Left + 6;
                if (tabFavicons.TryGetValue(tp, out var img) && img != null)
                {
                    try { e.Graphics.DrawImage(img, rect.Left + 6, rect.Top + 6, 16, 16); } catch { }
                    textX += 20;
                }

                using (var textBrush = new System.Drawing.SolidBrush(textColor))
                {
                    e.Graphics.DrawString(tp.Text, this.Font, textBrush, textX, rect.Top + 6);
                }

                // draw close 'x' on the right side of the tab
                var xRect = new System.Drawing.Rectangle(rect.Right - 18, rect.Top + 6, 12, 12);
                using (var xBrush = new System.Drawing.SolidBrush(System.Drawing.Color.LightGray))
                {
                    e.Graphics.DrawString("x", this.Font, xBrush, xRect.Left, xRect.Top - 2);
                }
            }
            catch { }
        }

        private void TabControl_MouseDown(object? sender, MouseEventArgs e)
        {
            try
            {
                for (int i = 0; i < tabControl.TabPages.Count; i++)
                {
                    var rect = tabControl.GetTabRect(i);
                    var xRect = new System.Drawing.Rectangle(rect.Right - 16, rect.Top + 6, 12, 12);
                    if (xRect.Contains(e.Location))
                    {
                        // close tab
                        tabControl.SelectedIndex = i;
                        btnCloseTab_Click(this, EventArgs.Empty);
                        return;
                    }
                }

                if (e.Button == MouseButtons.Right)
                {
                    // show context menu for tab under cursor
                    for (int i = 0; i < tabControl.TabPages.Count; i++)
                    {
                        var rect = tabControl.GetTabRect(i);
                        if (rect.Contains(e.Location))
                        {
                            tabControl.SelectedIndex = i;
                            tabContextMenu.Show(tabControl, e.Location);
                            return;
                        }
                    }
                }

                if (e.Button == MouseButtons.Left)
                {
                    // prepare for drag
                    for (int i = 0; i < tabControl.TabPages.Count; i++)
                    {
                        var rect = tabControl.GetTabRect(i);
                        if (rect.Contains(e.Location)) { dragTabIndex = i; break; }
                    }
                }
            }
            catch { }
        }

        private void TabControl_MouseMove(object? sender, MouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Left && dragTabIndex >= 0)
                {
                    // start drag
                    var tp = tabControl.TabPages[dragTabIndex];
                    tabControl.DoDragDrop(tp, DragDropEffects.Move);
                }
            }
            catch { }
        }

        private void TabControl_DragOver(object? sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void TabControl_DragDrop(object? sender, DragEventArgs e)
        {
            try
            {
                if (!(e.Data.GetData(typeof(TabPage)) is TabPage tp)) return;
                var pt = tabControl.PointToClient(new System.Drawing.Point(e.X, e.Y));
                for (int i = 0; i < tabControl.TabPages.Count; i++)
                {
                    var rect = tabControl.GetTabRect(i);
                    if (rect.Contains(pt))
                    {
                        var oldIndex = tabControl.TabPages.IndexOf(tp);
                        if (oldIndex != i)
                        {
                            tabControl.TabPages.Remove(tp);
                            tabControl.TabPages.Insert(i, tp);
                            tabControl.SelectedTab = tp;
                        }
                        break;
                    }
                }
                dragTabIndex = -1;
                SaveOpenTabs();
            }
            catch { }
        }

        private void Form1_KeyDown(object? sender, KeyEventArgs e)
        {
            try
            {
                if (e.Control && e.KeyCode == Keys.T) { _ = CreateNewTabAsync("about:blank"); e.Handled = true; }
                else if (e.Control && e.KeyCode == Keys.W) { btnCloseTab_Click(this, EventArgs.Empty); e.Handled = true; }
                else if (e.Control && e.KeyCode == Keys.Tab) { // Ctrl+Tab switch
                    var idx = tabControl.SelectedIndex;
                    if (idx < tabControl.TabCount - 1) tabControl.SelectedIndex = idx + 1; else tabControl.SelectedIndex = 0;
                    e.Handled = true;
                }
            }
            catch { }
        }

        private void SaveOpenTabs()
        {
            try
            {
                settings.OpenTabs.Clear();
                foreach (TabPage tp in tabControl.TabPages)
                {
                    foreach (Control c in tp.Controls)
                    {
                        if (c is WebView2 w)
                        {
                            settings.OpenTabs.Add(w.Source?.ToString() ?? "about:blank");
                            break;
                        }
                    }
                }
                settings.Save();
            }
            catch { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void browserPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void addressBar_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
