﻿namespace Vyra_Browser
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel browserPanel;
        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnForward;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnNewTab;
        private System.Windows.Forms.Button btnCloseTab;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.Button btnSettingsMain;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.TextBox addressBar;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            browserPanel = new Panel();
            tabControl = new TabControl();
            topPanel = new Panel();
            btnBack = new Button();
            btnForward = new Button();
            btnRefresh = new Button();
            btnNewTab = new Button();
            btnCloseTab = new Button();
            addressBar = new TextBox();
            btnSettings = new Button();
            btnGo = new Button();
            btnSettingsMain = new Button();
            browserPanel.SuspendLayout();
            topPanel.SuspendLayout();
            SuspendLayout();
            // 
            // browserPanel
            // 
            browserPanel.BackColor = Color.Black;
            browserPanel.Controls.Add(tabControl);
            browserPanel.Dock = DockStyle.Fill;
            browserPanel.Location = new Point(0, 28);
            browserPanel.Name = "browserPanel";
            browserPanel.Size = new Size(1482, 629);
            browserPanel.TabIndex = 6;
            browserPanel.Paint += browserPanel_Paint;
            // 
            // tabControl
            // 
            tabControl.BackColor = Color.Black;
            tabControl.Dock = DockStyle.Fill;
            tabControl.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabControl.ForeColor = Color.LightGray;
            tabControl.ItemSize = new Size(150, 28);
            tabControl.Location = new Point(0, 0);
            tabControl.Name = "tabControl";
            tabControl.Padding = new Point(10, 4);
            tabControl.SelectedIndex = 0;
            tabControl.Size = new Size(1482, 629);
            tabControl.TabIndex = 7;
            tabControl.SelectedIndexChanged += tabControl_SelectedIndexChanged;
            // 
            // topPanel
            // 
            topPanel.BackColor = Color.Black;
            topPanel.Controls.Add(btnBack);
            topPanel.Controls.Add(btnForward);
            topPanel.Controls.Add(btnRefresh);
            topPanel.Controls.Add(btnNewTab);
            topPanel.Controls.Add(btnCloseTab);
            topPanel.Controls.Add(addressBar);
            topPanel.Controls.Add(btnSettings);
            topPanel.Controls.Add(btnGo);
            topPanel.Dock = DockStyle.Top;
            topPanel.Location = new Point(0, 0);
            topPanel.Name = "topPanel";
            topPanel.Size = new Size(1482, 28);
            topPanel.TabIndex = 0;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(50, 50, 58);
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.ForeColor = Color.LightGray;
            btnBack.Location = new Point(6, 6);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(48, 23);
            btnBack.TabIndex = 1;
            btnBack.Text = "◀";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // btnForward
            // 
            btnForward.BackColor = Color.FromArgb(50, 50, 58);
            btnForward.FlatAppearance.BorderSize = 0;
            btnForward.FlatStyle = FlatStyle.Flat;
            btnForward.ForeColor = Color.LightGray;
            btnForward.Location = new Point(60, 6);
            btnForward.Name = "btnForward";
            btnForward.Size = new Size(48, 23);
            btnForward.TabIndex = 2;
            btnForward.Text = "▶";
            btnForward.UseVisualStyleBackColor = false;
            btnForward.Click += btnForward_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.BackColor = Color.FromArgb(50, 50, 58);
            btnRefresh.FlatAppearance.BorderSize = 0;
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.ForeColor = Color.LightGray;
            btnRefresh.Location = new Point(114, 6);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(52, 23);
            btnRefresh.TabIndex = 3;
            btnRefresh.Text = "⟳";
            btnRefresh.UseVisualStyleBackColor = false;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnNewTab
            // 
            btnNewTab.BackColor = Color.FromArgb(50, 50, 58);
            btnNewTab.FlatAppearance.BorderSize = 0;
            btnNewTab.FlatStyle = FlatStyle.Flat;
            btnNewTab.ForeColor = Color.LightGray;
            btnNewTab.Location = new Point(170, 6);
            btnNewTab.Name = "btnNewTab";
            btnNewTab.Size = new Size(48, 23);
            btnNewTab.TabIndex = 4;
            btnNewTab.Text = "+";
            btnNewTab.UseVisualStyleBackColor = false;
            btnNewTab.Click += btnNewTab_Click;
            // 
            // btnCloseTab
            // 
            btnCloseTab.BackColor = Color.FromArgb(50, 50, 58);
            btnCloseTab.FlatAppearance.BorderSize = 0;
            btnCloseTab.FlatStyle = FlatStyle.Flat;
            btnCloseTab.ForeColor = Color.LightGray;
            btnCloseTab.Location = new Point(224, 6);
            btnCloseTab.Name = "btnCloseTab";
            btnCloseTab.Size = new Size(48, 23);
            btnCloseTab.TabIndex = 4;
            btnCloseTab.Text = "x";
            btnCloseTab.UseVisualStyleBackColor = false;
            btnCloseTab.Click += btnCloseTab_Click;
            // 
            // addressBar
            // 
            addressBar.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            addressBar.BackColor = Color.FromArgb(55, 55, 62);
            addressBar.BorderStyle = BorderStyle.FixedSingle;
            addressBar.ForeColor = Color.White;
            addressBar.Location = new Point(278, 2);
            addressBar.Name = "addressBar";
            addressBar.Size = new Size(1090, 23);
            addressBar.TabIndex = 4;
            addressBar.TextChanged += addressBar_TextChanged;
            addressBar.KeyDown += addressBar_KeyDown;
            // 
            // btnSettings
            // 
            btnSettings.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSettings.BackColor = Color.FromArgb(50, 50, 58);
            btnSettings.FlatAppearance.BorderSize = 0;
            btnSettings.FlatStyle = FlatStyle.Flat;
            btnSettings.ForeColor = Color.LightGray;
            btnSettings.Location = new Point(1370, 6);
            btnSettings.Name = "btnSettings";
            btnSettings.Size = new Size(48, 23);
            btnSettings.TabIndex = 4;
            btnSettings.Text = "⚙";
            btnSettings.UseVisualStyleBackColor = false;
            btnSettings.Click += btnSettings_Click;
            // 
            // btnGo
            // 
            btnGo.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnGo.BackColor = Color.FromArgb(70, 70, 78);
            btnGo.FlatAppearance.BorderSize = 0;
            btnGo.FlatStyle = FlatStyle.Flat;
            btnGo.ForeColor = Color.White;
            btnGo.Location = new Point(1426, 3);
            btnGo.Name = "btnGo";
            btnGo.Size = new Size(48, 23);
            btnGo.TabIndex = 5;
            btnGo.Text = "Go";
            btnGo.UseVisualStyleBackColor = false;
            btnGo.Click += btnGo_Click;
            // 
            // btnSettingsMain
            // 
            btnSettingsMain.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSettingsMain.BackColor = Color.FromArgb(70, 70, 78);
            btnSettingsMain.FlatAppearance.BorderSize = 0;
            btnSettingsMain.FlatStyle = FlatStyle.Flat;
            btnSettingsMain.ForeColor = Color.White;
            btnSettingsMain.Location = new Point(966, 468);
            btnSettingsMain.Name = "btnSettingsMain";
            btnSettingsMain.Size = new Size(80, 28);
            btnSettingsMain.TabIndex = 7;
            btnSettingsMain.Text = "Settings";
            btnSettingsMain.UseVisualStyleBackColor = false;
            btnSettingsMain.Click += btnSettingsMain_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1482, 657);
            Controls.Add(browserPanel);
            Controls.Add(topPanel);
            Controls.Add(btnSettingsMain);
            ForeColor = Color.LightGray;
            Name = "Form1";
            Text = "Vyra Browser";
            Load += Form1_Load;
            browserPanel.ResumeLayout(false);
            topPanel.ResumeLayout(false);
            topPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
    }
}
